'''Scrivere un programma che acquisisca una stringa inserita dall'utente e calcoli il numero 
totale di spazi presenti nella stringa. Il risultato deve essere visualizzato in output.'''


#ho inizializzato la variabile per l'input e ho ultilizzato il ciclo for.Col print,ho calcolato la lunghezza della variabile inserita.


parola=(input())
for i in parola:
    print(len(parola))
    break